#week09
#chater06
##FLASK @ SQLAchemy
*บทนี้เราเรียนรู้เกี่ยวกับการใช้งาน flask ร่วมกับ SQLLachemy